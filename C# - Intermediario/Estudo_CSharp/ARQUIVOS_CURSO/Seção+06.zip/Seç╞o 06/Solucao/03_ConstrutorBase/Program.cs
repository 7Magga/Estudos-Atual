﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_ConstrutorBase
{
    class Program_03_ConstrutorBase
    {
        static void Main(string[] args)
        {
            Carro carro = new Carro(19);

            Console.ReadKey();
        }
    }
}
