﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_PalavraThis
{
    class Carro
    {
        string Marca;
        string Modelo;
        string AnoFabricacao;
        string AnoModelo;

        public void SetMarca(String Marca)
        {
            this.Marca = Marca;
            
        }

        public void SetModelo(String Modelo)
        {

        }
    }
}
