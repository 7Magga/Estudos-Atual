﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Construtores
{
    class Program
    {
        static void Main(string[] args)
        {
            Pessoa pessoa = new Pessoa("José", "M", DateTime.Now, 20.0, 10.3);

        }
    }
}
