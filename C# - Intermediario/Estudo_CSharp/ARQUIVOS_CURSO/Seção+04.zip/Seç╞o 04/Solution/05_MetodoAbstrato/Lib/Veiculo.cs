﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_MetodoAbstrato.Lib
{
    abstract class Veiculo
    {
        abstract public void MudarMarcha(byte NumeroMarcha);
    }
}
