﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _04_ClasseAbstrata.Lib;
namespace _04_ClasseAbstrata
{
    class Program
    {
        static void Main(string[] args)
        {
            Veiculo vei = new Veiculo();
            Carro carro = new Carro();
            Caminhao caminhao = new Caminhao();
        }
    }
}
