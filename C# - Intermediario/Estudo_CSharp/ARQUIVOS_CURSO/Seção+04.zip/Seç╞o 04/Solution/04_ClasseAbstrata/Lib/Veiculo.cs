﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_ClasseAbstrata.Lib
{
    abstract class Veiculo
    {
        string Marca;
        string Modelo;
        string AnoModeloFabricacao;
        byte Eixos;
        byte Rodas;

    }
}
