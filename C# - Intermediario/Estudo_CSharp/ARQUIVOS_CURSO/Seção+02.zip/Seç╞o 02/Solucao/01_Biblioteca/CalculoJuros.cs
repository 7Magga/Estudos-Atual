﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Biblioteca
{
    public class CalculoJuros
    {
        public double Soma(int A, int B)
        {
            return A + B;
        }
    }
}
