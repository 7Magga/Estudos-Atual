﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_ModificadoresAcessoParte1.Lib
{
    public class Carro : Veiculo
    {
        byte QtRodas = 4;

        void InfoCarro()
        {
            Marca = "VW";
            Modelo = "Gol";
            
            //AnoFabricao
        }
    }
}
